import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from pymavlink import mavutil
import time

class PositionInfoPublisher(Node):

    def __init__(self):
        super().__init__('attitude_publisher')
        self.publisher_ = self.create_publisher(Float64MultiArray, 'attitude', 10)
        timer_period = 0.1  # 10Hz
        self.timer = self.create_timer(timer_period, self.send_info)
        self.data = [0.0] * 7  # roll, pitch, yaw, rollspd, pitchspd, yawspeed, battery

        # Setup MAVLink connection
        self.connect_pixhawk()

    def connect_pixhawk(self):
        self.get_logger().info('Connecting to Pixhawk...')
        CONNECTION_PORT = '/dev/serial/by-id/usb-ArduPilot_fmuv2_31003D001751383435323530-if00'
        CONNECTION_BAUD = 115200

        self.drone = mavutil.mavlink_connection(CONNECTION_PORT, CONNECTION_BAUD)
        self.drone.wait_heartbeat()
        self.get_logger().info('Pixhawk heartbeat received.')

        # Set data stream request
        self.drone.mav.request_data_stream_send(
            self.drone.target_system,
            self.drone.target_component,
            mavutil.mavlink.MAV_DATA_STREAM_EXTRA1,
            50,  # Hz
            1
        )
        time.sleep(1)

        # Request battery info at slower interval
        self.drone.mav.message_interval_send(
            mavutil.mavlink.MAVLINK_MSG_ID_BATTERY_STATUS,
            10000000  # in microseconds
        )

    def send_info(self):
        attitude = self.drone.recv_match(type='ATTITUDE', blocking=False)
        if attitude:
            self.data[0] = attitude.roll
            self.data[1] = attitude.pitch
            self.data[2] = attitude.yaw
            self.data[3] = attitude.rollspeed
            self.data[4] = attitude.pitchspeed
            self.data[5] = attitude.yawspeed

        battery = self.drone.recv_match(type='BATTERY_STATUS', blocking=False)
        if battery:
            self.data[6] = battery.battery_remaining

        msg = Float64MultiArray()
        msg.data = self.data
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = PositionInfoPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
