import time

class AdaptivePID:
    def __init__(self, base_Kp, base_Ki, base_Kd, axis_name=""):
        # Base gains
        self.base_Kp = base_Kp
        self.base_Ki = base_Ki
        self.base_Kd = base_Kd

        # Adaptive gains
        self.Kp = base_Kp
        self.Ki = base_Ki
        self.Kd = base_Kd

        # Error terms
        self.prev_error = 0.0
        self.integral = 0.0

        # Timing
        self.prev_time = time.time()

        # Optional label
        self.axis = axis_name

    def update_gains(self, error, d_error, i_error):
        # Adaptive logic (tune these weights as needed)
        self.Kp = self.base_Kp + 0.5 * abs(d_error)
        self.Ki = self.base_Ki + 0.05 * abs(i_error)
        self.Kd = self.base_Kd + 0.1 * abs(d_error)

    def compute(self, setpoint, measurement):
        current_time = time.time()
        dt = current_time - self.prev_time
        if dt == 0:
            dt = 1e-6  # Avoid division by zero

        # Error calculation
        error = setpoint - measurement
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt

        # Adapt gains dynamically
        self.update_gains(error, derivative, self.integral)

        # PID output
        output = (
            self.Kp * error +
            self.Ki * self.integral +
            self.Kd * derivative
        )

        # Update state
        self.prev_error = error
        self.prev_time = current_time

        return output

    def reset(self):
        self.prev_error = 0.0
        self.integral = 0.0
        self.prev_time = time.time()

    def get_gains(self):
        return (self.Kp, self.Ki, self.Kd)
