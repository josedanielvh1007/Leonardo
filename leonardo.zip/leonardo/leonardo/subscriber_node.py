from rclpy.node import Node
import rclpy

from std_msgs.msg import Float64MultiArray
from adaptive_pid import AdaptivePID

import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

motor_pins = [12, 13, 18, 19]  # BCM GPIO numbers
GPIO.setup(motor_pins, GPIO.OUT)

motors = [GPIO.PWM(pin, 50) for pin in motor_pins]  # 50Hz para ESCs

for motor in motors:
    motor.start(7.5)  # 1500µs como neutral (7.5%)

def microseconds_to_duty(pulse_us):
    # Convierte 1000–2000 µs a 5%–10% duty cycle (ESC típico)
    return 5 + (pulse_us - 1000) * (5 / 1000)

class AttitudeSubscriber(Node):

    def __init__(self):
        super().__init__('attitude_subscriber')

        self.subscription = self.create_subscription(
            Float64MultiArray,
            'attitude',
            self.receive_info,
            10
        )

        self.roll_pid = AdaptivePID(2.0, 0.01, 1.0, axis_name="roll")
        self.pitch_pid = AdaptivePID(2.0, 0.01, 1.0, axis_name="pitch")

        self.base_pwm = 1500
        self.max_pwm = 2000
        self.min_pwm = 1000

    def receive_info(self, msg):
        data = msg.data
        roll, pitch = data[0], data[1]

        desired_roll = 0.0
        desired_pitch = 0.0

        roll_corr = self.roll_pid.compute(desired_roll, roll)
        pitch_corr = self.pitch_pid.compute(desired_pitch, pitch)

        motor_pwm = [0] * 4
        motor_pwm[0] = self.base_pwm - roll_corr + pitch_corr  # FR
        motor_pwm[1] = self.base_pwm + roll_corr + pitch_corr  # FL
        motor_pwm[2] = self.base_pwm + roll_corr - pitch_corr  # BL
        motor_pwm[3] = self.base_pwm - roll_corr - pitch_corr  # BR

        motor_pwm = [int(min(max(pwm, self.min_pwm), self.max_pwm)) for pwm in motor_pwm]

        self.get_logger().info(f'Motor PWMs: {motor_pwm} | Roll: {roll:.2f}, Pitch: {pitch:.2f}')

        for i in range(4):
            duty = microseconds_to_duty(motor_pwm[i])
            motors[i].ChangeDutyCycle(duty)

def main(args=None):
    rclpy.init(args=args)
    node = AttitudeSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("Shutting down...")
    finally:
        for motor in motors:
            motor.ChangeDutyCycle(0)
            motor.stop()
        GPIO.cleanup()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
