from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='leonardo',
            executable='attitude_publisher',
            name='attitude_publisher'
        ),
        Node(
            package='leonardo',
            executable='attitude_subscriber',
            name='attitude_subscriber'
        )
    ])
