from setuptools import setup

package_name = 'leonardo'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/attitude_control.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='jose_daniel',
    maintainer_email='@example.com',
    description='ROS 2 package for publishing and subscribing drone attitude data.',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'attitude_publisher = src.publisher_node:main',
            'attitude_subscriber = src.subscriber_node:main',
        ],
    },
)
